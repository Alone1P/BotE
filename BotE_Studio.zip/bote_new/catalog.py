# -*- coding: utf-8 -*-
"""
كتالوج الأوامر والمكعبات.
كل مكعب = نوع (type) + تصنيف (category) + اسم عرض (label) + الحقول المطلوبة منه.
لإضافة مكعب جديد: أضف سطراً هنا، ونفّذه في app.py داخل execute_block().
الواجهة تبني نفسها تلقائياً من هذه القائمة، فلا حاجة لتعديل HTML.
"""

CATEGORIES = {
    "core":       ("أساسي",         "ردود، أزرار، قوائم ونماذج"),
    "tools":      ("أدوات",          "نصوص، أرقام، وتحويلات"),
    "web":        ("ويب وAPI",       "طلبات، كشط صفحات، RSS وJSON"),
    "ai":         ("ذكاء اصطناعي",   "رد ذكي، تلخيص، وإعادة صياغة"),
    "media":      ("وسائط",          "صور، صوت، فيديو وملفات"),
    "automation": ("أتمتة",          "شروط، تأخير، وجدولة دورية"),
    "commerce":   ("نقاط ومتجر",     "نقاط، مكافآت ومنتجات"),
    "admin":      ("إدارة",          "إحصاءات، إذاعة وصلاحيات"),
}

# أوامر جاهزة (بادئة /) يمكن ربطها مباشرة بمكعب "أمر مخصص" من الكتالوج
BUILTIN_COMMANDS = [
    "start", "help", "menu", "about", "rules", "support", "ping", "id", "profile",
    "time", "status", "settings", "language", "cancel", "invite", "referrals",
    "points", "leaderboard", "daily", "redeem",
    "echo", "roll", "dice", "8ball", "joke", "quote", "weather", "translate",
    "qr", "calc", "convert", "remind",
    "broadcast", "stats", "ban", "unban", "warn",
    "ai", "ask", "summarize",
]

# كل مكعب: (النوع، التصنيف، الاسم المعروض، الحقول)
BLOCK_DEFINITIONS = [
    # -- أساسي --
    ("reply",       "core", "رد نصي",              ["trigger", "reply"]),
    ("buttons",     "core", "رسالة بأزرار",         ["trigger", "reply", "buttons"]),
    ("command",     "core", "أمر مخصص",             ["command", "reply"]),
    ("form",        "core", "نموذج (سؤال ثم رد)",   ["trigger", "questions", "finish_reply"]),
    ("set_variable","core", "تعيين متغير",          ["trigger", "name", "value", "reply"]),

    # -- أدوات (نصوص/أرقام) --
    ("uppercase",   "tools", "أحرف كبيرة",          ["trigger", "reply"]),
    ("lowercase",   "tools", "أحرف صغيرة",          ["trigger", "reply"]),
    ("reverse",     "tools", "عكس النص",            ["trigger", "reply"]),
    ("count_words", "tools", "عد الكلمات/الحروف",   ["trigger", "reply"]),
    ("random_choice","tools","اختيار عشوائي",       ["trigger", "choices", "reply"]),
    ("random_number","tools","رقم عشوائي",          ["trigger", "minimum", "maximum", "reply"]),
    ("calc",        "tools", "آلة حاسبة",           ["trigger"]),
    ("uuid",        "tools", "توليد UUID",          ["trigger", "reply"]),
    ("hash",        "tools", "تجزئة (hash)",        ["trigger", "algorithm", "reply"]),
    ("base64",      "tools", "ترميز Base64",        ["trigger", "mode", "reply"]),
    ("qr_code",     "tools", "رمز QR",               ["trigger", "reply"]),

    # -- ويب وAPI --
    ("api",         "web", "طلب API (GET)",         ["trigger", "url", "reply"]),
    ("scrape",      "web", "كشط صفحة ويب",           ["trigger", "url", "reply"]),
    ("json_extract","web", "استخراج قيمة JSON",      ["trigger", "url", "path", "reply"]),
    ("rss",         "web", "قارئ RSS",               ["trigger", "url", "reply"]),
    ("website_status","web","حالة موقع (يعمل؟)",     ["trigger", "url", "reply"]),

    # -- ذكاء اصطناعي --
    ("ai",          "ai", "وكيل AI (سؤال وجواب)",    ["trigger", "prompt", "reply"]),
    ("summarize",   "ai", "تلخيص نص المستخدم",       ["trigger", "prompt"]),
    ("rewrite",     "ai", "إعادة صياغة",             ["trigger", "prompt"]),
    ("ai_translate","ai", "ترجمة بالذكاء الاصطناعي",  ["trigger", "language", "prompt"]),

    # -- وسائط --
    ("photo",       "media", "إرسال صورة",           ["trigger", "file_id", "caption"]),
    ("video",       "media", "إرسال فيديو",          ["trigger", "file_id", "caption"]),
    ("voice",       "media", "إرسال صوت",            ["trigger", "file_id", "caption"]),
    ("file",        "media", "إرسال ملف",            ["trigger", "file_id", "caption"]),
    ("location",    "media", "إرسال موقع",           ["trigger", "latitude", "longitude", "reply"]),

    # -- أتمتة --
    ("condition",   "automation", "شرط (إذا/وإلا)",  ["trigger", "condition", "reply", "else_reply"]),
    ("delay",       "automation", "تأخير قبل الرد",  ["trigger", "seconds", "reply"]),
    ("schedule",    "automation", "رسالة دورية مجدولة", ["chat_id", "interval", "message"]),
    ("cooldown",    "automation", "منع التكرار السريع", ["trigger", "seconds", "reply"]),

    # -- نقاط ومتجر --
    ("points",      "commerce", "إضافة/خصم نقاط",    ["trigger", "amount", "reply"]),
    ("leaderboard", "commerce", "لوحة المتصدرين",     ["trigger", "reply"]),
    ("shop_product","commerce", "عرض منتج",           ["trigger", "name", "price", "reply"]),
    ("coupon",      "commerce", "كوبون خصم",          ["trigger", "code", "amount", "reply"]),

    # -- إدارة --
    ("admin_action","admin", "إجراء إداري (كتم/حظر)", ["trigger", "action", "reply"]),
    ("user_stats",  "admin", "إحصاءات المستخدمين",    ["trigger", "reply"]),
    ("role_check",  "admin", "فحص صلاحية المستخدم",   ["trigger", "role", "reply"]),
]

# دمج التصنيف في كل عنصر كي تستخدمه الواجهة والمحرك مباشرة كقاموس
BLOCKS = [
    {"type": t, "category": c, "label": label, "fields": fields}
    for t, c, label, fields in BLOCK_DEFINITIONS
]
BLOCKS_BY_TYPE = {b["type"]: b for b in BLOCKS}

__all__ = ["CATEGORIES", "BUILTIN_COMMANDS", "BLOCK_DEFINITIONS", "BLOCKS", "BLOCKS_BY_TYPE"]
