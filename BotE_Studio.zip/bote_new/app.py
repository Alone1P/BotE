# -*- coding: utf-8 -*-
"""
BotE Studio — نقطة تشغيل واحدة تجمع:
  - الإعدادات والتخزين الدائم (JSON + SQLite)
  - محرك بوت Telegram (تنفيذ المكعبات)
  - لوحة الويب Flask + واجهة API
كل هذا في عملية واحدة، فلا حاجة لاستضافة منفصلة للبوت:
عند الضغط على "حفظ وتشغيل" يبدأ البوت في Thread داخلي بجانب خادم الويب.
"""
from __future__ import annotations

import base64
import hashlib
import ipaddress
import json
import os
import random
import re
import secrets
import sqlite3
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict
from urllib.parse import quote, urlparse

import requests
from bs4 import BeautifulSoup
from flask import Flask, jsonify, request, render_template
import telebot
from telebot import types

from catalog import BUILTIN_COMMANDS, BLOCKS, BLOCKS_BY_TYPE, CATEGORIES

# ---------------------------------------------------------------------------
# الإعدادات والتخزين
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DATA_DIR", str(ROOT / "data")))
DB_FILE = os.getenv("DB_FILE", str(DATA_DIR / "bote_data.db"))
CONFIG_FILE = os.getenv("BOT_CONFIG_FILE", str(DATA_DIR / "bote_config.json"))
PANEL_TOKEN = os.getenv("PANEL_TOKEN", "")
MAX_BLOCKS = int(os.getenv("MAX_BLOCKS", "500"))

DEFAULT_CONFIG = {
    "token": "",
    "owner_id": "",
    "default_reply": "لم أفهم طلبك، جرّب /help",
    "blocks": [],
    "ai": {"enabled": False, "provider": "openai", "api_key": "", "base_url": "", "model": "", "command": "/ai"},
}


def db() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_FILE, timeout=20)
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db() -> None:
    with db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY, first_name TEXT, username TEXT,
                points INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_seen TEXT
            );
            CREATE TABLE IF NOT EXISTS chats (
                chat_id TEXT PRIMARY KEY, chat_type TEXT, title TEXT,
                joined_at TEXT DEFAULT CURRENT_TIMESTAMP, last_activity TEXT
            );
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id TEXT, chat_type TEXT, user_id TEXT, username TEXT,
                text TEXT, direction TEXT DEFAULT 'in',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, id);
            """
        )


def load_config() -> Dict[str, Any]:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    p = Path(CONFIG_FILE)
    if p.exists():
        try:
            cfg.update(json.loads(p.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            pass
    return cfg


def save_config(cfg: Dict[str, Any]) -> None:
    p = Path(CONFIG_FILE)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)


def save_user(message) -> None:
    u = message.from_user
    with db() as c:
        c.execute(
            """INSERT INTO users(user_id, first_name, username, last_seen)
               VALUES (?, ?, ?, datetime('now'))
               ON CONFLICT(user_id) DO UPDATE SET
                 first_name=excluded.first_name, username=excluded.username, last_seen=excluded.last_seen""",
            (str(u.id), u.first_name or "", u.username or ""),
        )


def get_points(uid) -> int:
    with db() as c:
        row = c.execute("SELECT points FROM users WHERE user_id=?", (str(uid),)).fetchone()
    return int(row[0]) if row else 0


def add_points(uid, n: int) -> None:
    with db() as c:
        c.execute("UPDATE users SET points = points + ? WHERE user_id=?", (int(n), str(uid)))


def all_user_ids() -> list[str]:
    with db() as c:
        return [row[0] for row in c.execute("SELECT user_id FROM users").fetchall()]


def user_count() -> int:
    with db() as c:
        return c.execute("SELECT COUNT(*) FROM users").fetchone()[0]


MAX_LOGGED_MESSAGES = int(os.getenv("MAX_LOGGED_MESSAGES", "5000"))


def save_chat(chat) -> None:
    """يسجّل أي محادثة (خاصة/مجموعة/قناة) يتفاعل معها البوت."""
    title = getattr(chat, "title", None) or getattr(chat, "first_name", None) or getattr(chat, "username", None) or str(chat.id)
    with db() as c:
        c.execute(
            """INSERT INTO chats(chat_id, chat_type, title, last_activity)
               VALUES (?, ?, ?, datetime('now'))
               ON CONFLICT(chat_id) DO UPDATE SET
                 chat_type=excluded.chat_type, title=excluded.title, last_activity=excluded.last_activity""",
            (str(chat.id), chat.type, title),
        )


def save_message(chat, user, text: str, direction: str = "in") -> None:
    if not text:
        return
    with db() as c:
        c.execute(
            """INSERT INTO messages(chat_id, chat_type, user_id, username, text, direction)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (str(chat.id), getattr(chat, "type", ""), str(getattr(user, "id", "")), getattr(user, "username", "") or "", text[:2000], direction),
        )
        # يحافظ على حجم السجل بحذف الأقدم عند تجاوز الحد
        c.execute(
            "DELETE FROM messages WHERE id NOT IN (SELECT id FROM messages ORDER BY id DESC LIMIT ?)",
            (MAX_LOGGED_MESSAGES,),
        )


def list_chats() -> list[Dict[str, Any]]:
    with db() as c:
        rows = c.execute(
            "SELECT chat_id, chat_type, title, joined_at, last_activity FROM chats ORDER BY last_activity DESC"
        ).fetchall()
    return [
        {"chat_id": r[0], "chat_type": r[1], "title": r[2], "joined_at": r[3], "last_activity": r[4]}
        for r in rows
    ]


def list_messages(chat_id: str, limit: int = 100) -> list[Dict[str, Any]]:
    with db() as c:
        rows = c.execute(
            "SELECT username, user_id, text, direction, created_at FROM messages WHERE chat_id=? ORDER BY id DESC LIMIT ?",
            (str(chat_id), limit),
        ).fetchall()
    return [
        {"username": r[0], "user_id": r[1], "text": r[2], "direction": r[3], "created_at": r[4]}
        for r in reversed(rows)
    ]


init_db()

# ---------------------------------------------------------------------------
# محرك Telegram
# ---------------------------------------------------------------------------
_bot_instance = None
_bot_lock = threading.RLock()

_BLOCKED_HOSTS = {"localhost"}


def safe_url(url: str) -> bool:
    """يمنع طلب أي رابط يشير لمضيف محلي أو شبكة داخلية (حماية من SSRF)."""
    try:
        p = urlparse(url)
        if p.scheme not in ("http", "https") or not p.hostname:
            return False
        host = p.hostname.lower()
        if host in _BLOCKED_HOSTS:
            return False
        try:
            ip = ipaddress.ip_address(host)
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
                return False
        except ValueError:
            pass  # ليس IP خام، اسم نطاق عادي
        return True
    except Exception:
        return False


def replace_vars(text: str, message) -> str:
    u = getattr(message, "from_user", None)
    chat = getattr(message, "chat", None)
    values = {
        "#first_name": getattr(u, "first_name", None) or "صديقي",
        "#username": getattr(u, "username", None) or "بدون_يوزر",
        "#user_id": str(getattr(u, "id", "")),
        "#points": str(get_points(getattr(u, "id", ""))),
        "#chat_id": str(getattr(chat, "id", "")),
        "#date": datetime.now().strftime("%Y-%m-%d"),
        "#time": datetime.now().strftime("%H:%M"),
    }
    text = str(text or "")
    for key, val in values.items():
        text = text.replace(key, val)
    return text


def build_markup(raw):
    if not raw:
        return None
    m = types.InlineKeyboardMarkup()
    rows = raw if isinstance(raw, list) else str(raw).splitlines()
    for row in rows:
        if isinstance(row, dict):
            label, url = row.get("text", "فتح"), row.get("url", "")
        else:
            parts = str(row).split("|", 1)
            label, url = (parts + [""])[:2]
        if label and url and safe_url(url):
            m.add(types.InlineKeyboardButton(label[:64], url=url))
    return m if m.keyboard else None


def call_ai(prompt: str, cfg: Dict[str, Any]) -> str:
    a = cfg.get("ai", {})
    key = a.get("api_key") or os.getenv("OPENAI_API_KEY")
    base = a.get("base_url") or os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1")
    model = a.get("model") or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    if not key:
        return "⚠️ لم يتم ضبط مزود الذكاء الاصطناعي بعد."
    if a.get("provider") == "gemini" or "generativelanguage" in base:
        gmodel = model or "gemini-1.5-flash"
        r = requests.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{gmodel}:generateContent?key={key}",
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=40,
        )
        r.raise_for_status()
        return r.json()["candidates"][0]["content"]["parts"][0]["text"]
    r = requests.post(
        base.rstrip("/") + "/chat/completions",
        headers={"Authorization": f"Bearer {key}"},
        json={"model": model, "messages": [{"role": "user", "content": prompt}]},
        timeout=40,
    )
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]


def execute_block(bot, msg, block: Dict[str, Any], cfg: Dict[str, Any]) -> bool:
    kind = block.get("type", "reply")
    text = msg.text or ""
    parts = text.split(maxsplit=1)
    value = parts[1] if len(parts) > 1 else ""
    chat_id = msg.chat.id
    try:
        if kind in ("reply", "command"):
            bot.send_message(chat_id, replace_vars(block.get("reply", ""), msg))

        elif kind == "buttons":
            bot.send_message(chat_id, replace_vars(block.get("reply", ""), msg), reply_markup=build_markup(block.get("buttons")))

        elif kind == "form":
            bot.send_message(chat_id, replace_vars(block.get("questions", "").split("\n")[0] if block.get("questions") else "", msg))

        elif kind == "set_variable":
            bot.send_message(chat_id, replace_vars(block.get("reply", "تم الحفظ"), msg))

        elif kind in ("ai", "summarize", "rewrite", "ai_translate"):
            base_prompt = block.get("prompt") or value
            if kind == "summarize":
                base_prompt = f"لخص هذا النص بإيجاز:\n{value or base_prompt}"
            elif kind == "rewrite":
                base_prompt = f"أعد صياغة هذا النص:\n{value or base_prompt}"
            elif kind == "ai_translate":
                lang = block.get("language", "الإنجليزية")
                base_prompt = f"ترجم هذا النص إلى {lang}:\n{value or base_prompt}"
            bot.send_message(chat_id, call_ai(base_prompt, cfg))

        elif kind in ("api", "scrape", "json_extract", "website_status", "rss"):
            url = block.get("url", "")
            if not safe_url(url):
                raise ValueError("unsafe url")
            r = requests.get(url, timeout=12, headers={"User-Agent": "BotEStudio/1.0"})
            if kind == "website_status":
                result = f"✅ الموقع يعمل ({r.status_code})" if r.ok else f"⚠️ رمز الحالة: {r.status_code}"
            elif kind == "scrape":
                soup = BeautifulSoup(r.text, "html.parser")
                for tag in soup(["script", "style", "noscript"]):
                    tag.decompose()
                result = soup.get_text(" ", strip=True)[:3500]
            elif kind == "json_extract":
                obj = r.json()
                for key in (block.get("path") or "").split("."):
                    if not key:
                        continue
                    obj = obj.get(key, "") if isinstance(obj, dict) else ""
                result = str(obj)
            elif kind == "rss":
                soup = BeautifulSoup(r.text, "xml")
                items = soup.find_all("item")[:5]
                result = "\n".join(f"• {i.title.text}" for i in items if i.title) or "لا توجد عناصر."
            else:
                result = r.text[:3500]
            bot.send_message(chat_id, replace_vars((block.get("reply") or "{result}").replace("{result}", result), msg))

        elif kind in ("photo", "video", "voice", "file"):
            sender = {"photo": bot.send_photo, "video": bot.send_video, "voice": bot.send_voice, "file": bot.send_document}[kind]
            sender(chat_id, block.get("file_id"), caption=replace_vars(block.get("caption", ""), msg))

        elif kind == "location":
            bot.send_location(chat_id, float(block.get("latitude", 0)), float(block.get("longitude", 0)))

        elif kind in ("uppercase", "lowercase", "reverse", "count_words", "random_choice", "random_number", "uuid", "hash", "base64"):
            if kind == "uppercase":
                value = value.upper()
            elif kind == "lowercase":
                value = value.lower()
            elif kind == "reverse":
                value = value[::-1]
            elif kind == "count_words":
                value = f"كلمات: {len(value.split())} · حروف: {len(value)}"
            elif kind == "random_choice":
                choices = [x.strip() for x in block.get("choices", "").split(",") if x.strip()]
                value = random.choice(choices) if choices else "لا توجد اختيارات"
            elif kind == "random_number":
                value = str(random.randint(int(block.get("minimum", 1)), int(block.get("maximum", 100))))
            elif kind == "uuid":
                value = str(uuid.uuid4())
            elif kind == "hash":
                algo = block.get("algorithm", "sha256")
                value = hashlib.new(algo, value.encode()).hexdigest()
            elif kind == "base64":
                value = base64.b64encode(value.encode()).decode() if block.get("mode") != "decode" else base64.b64decode(value).decode(errors="replace")
            bot.send_message(chat_id, replace_vars((block.get("reply") or "{result}").replace("{result}", value), msg))

        elif kind == "qr_code":
            data = quote(value or block.get("trigger", ""))
            bot.send_photo(chat_id, f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={data}")

        elif kind == "calc":
            if not re.fullmatch(r"[0-9+\-*/(). %]+", value or ""):
                raise ValueError("invalid expression")
            bot.send_message(chat_id, "🧮 " + str(eval(value, {"__builtins__": {}}, {})))

        elif kind == "condition":
            cond = block.get("condition", "").lower()
            reply = block.get("reply") if cond in text.lower() else block.get("else_reply", "")
            bot.send_message(chat_id, replace_vars(reply, msg))

        elif kind in ("delay", "cooldown"):
            time.sleep(min(float(block.get("seconds", 1)), 10))
            bot.send_message(chat_id, replace_vars(block.get("reply", ""), msg))

        elif kind == "points":
            add_points(msg.from_user.id, int(block.get("amount", 1)))
            bot.send_message(chat_id, replace_vars(block.get("reply", "تمت إضافة النقاط ✅"), msg))

        elif kind == "leaderboard":
            bot.send_message(chat_id, f"🏆 رصيدك الحالي: {get_points(msg.from_user.id)} نقطة")

        elif kind in ("shop_product", "coupon"):
            bot.send_message(chat_id, replace_vars(block.get("reply", ""), msg))

        elif kind in ("admin_action", "role_check"):
            bot.send_message(chat_id, replace_vars(block.get("reply", "تم"), msg))

        elif kind == "user_stats":
            bot.send_message(chat_id, f"👥 عدد المستخدمين: {user_count()}")

        else:
            bot.send_message(chat_id, replace_vars(block.get("reply", "تم تنفيذ المكعب."), msg))
        return True
    except Exception:
        bot.send_message(chat_id, "❌ تعذر تنفيذ هذا المكعب، تحقق من إعداداته.")
        return True


def block_matches(block: Dict[str, Any], text: str, command: str = "") -> bool:
    trigger = str(block.get("trigger") or block.get("command") or "").lower().lstrip("/")
    if not trigger:
        return False
    return trigger == command.lower().lstrip("/") if command else trigger in text.lower()


def handle_message(msg, command: str, cfg: Dict[str, Any]) -> bool:
    save_user(msg)
    save_chat(msg.chat)
    text = (msg.text or "").strip()
    save_message(msg.chat, msg.from_user, text, direction="in")
    ai_cfg = cfg.get("ai", {})
    ai_cmd = ai_cfg.get("command", "/ai")
    if ai_cfg.get("enabled") and text.startswith(ai_cmd):
        reply = call_ai(text[len(ai_cmd):].strip(), cfg)
        _bot_instance.send_message(msg.chat.id, reply)
        save_message(msg.chat, msg.from_user, reply, direction="out")
        return True
    for block in cfg.get("blocks", [])[:MAX_BLOCKS]:
        if block_matches(block, text, command):
            handled = execute_block(_bot_instance, msg, block, cfg)
            reply_text = replace_vars(block.get("reply", ""), msg) if block.get("reply") else ""
            if reply_text:
                save_message(msg.chat, msg.from_user, reply_text, direction="out")
            return handled
    return False


def start_bot(cfg: Dict[str, Any] | None = None) -> None:
    global _bot_instance
    cfg = cfg or load_config()
    token = cfg.get("token")
    if not token:
        raise ValueError("BOT_TOKEN غير مضبوط")

    bot = telebot.TeleBot(token, threaded=True, num_threads=8)
    with _bot_lock:
        _bot_instance = bot

    @bot.message_handler(commands=BUILTIN_COMMANDS)
    def on_command(msg):
        cmd = (msg.text or "").split()[0].split("@")[0].lstrip("/")
        if handle_message(msg, cmd, cfg):
            return
        if cmd in ("start", "help", "menu"):
            bot.send_message(msg.chat.id, "🚀 البوت يعمل بواسطة BotE Studio\nالأوامر: /help /id /points")
        elif cmd == "id":
            bot.send_message(msg.chat.id, f"🆔 {msg.from_user.id}")
        elif cmd in ("points",):
            bot.send_message(msg.chat.id, f"💰 رصيدك: {get_points(msg.from_user.id)} نقطة")
        elif cmd == "ping":
            bot.send_message(msg.chat.id, "🏓 Pong")

    @bot.message_handler(func=lambda m: True, content_types=["text", "photo", "document", "voice", "audio", "video", "location"])
    def on_message(msg):
        if not handle_message(msg, "", cfg):
            default = cfg.get("default_reply", "")
            if default and msg.text:
                bot.send_message(msg.chat.id, default)
                save_message(msg.chat, msg.from_user, default, direction="out")

    @bot.my_chat_member_handler()
    def on_membership_change(update):
        # يسجّل أي مجموعة أو قناة يُضاف إليها البوت أو تُحدَّث صلاحياته فيها
        try:
            save_chat(update.chat)
        except Exception:
            pass

    bot.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)


def stop_bot() -> None:
    global _bot_instance
    with _bot_lock:
        if _bot_instance:
            try:
                _bot_instance.stop_polling()
            except Exception:
                pass
        _bot_instance = None


def bot_running() -> bool:
    return _bot_instance is not None


def restart_bot(cfg: Dict[str, Any]) -> None:
    stop_bot()
    threading.Thread(target=start_bot, args=(cfg,), daemon=True, name="telegram-bot").start()


def _tg_api(token: str, method: str, **params):
    """نداء مباشر لـ Telegram Bot API، يُستخدم لهوية البوت (اسم/صورة) بدل الاعتماد
    على نسخة مكتبة pyTelegramBotAPI المثبّتة."""
    r = requests.post(f"https://api.telegram.org/bot{token}/{method}", data=params, timeout=15)
    data = r.json()
    if not data.get("ok"):
        raise ValueError(data.get("description", "خطأ من Telegram"))
    return data.get("result")


def get_bot_identity(token: str) -> Dict[str, Any]:
    """يجيب بيانات البوت (يوزر، اسم، هل يقبل الانضمام لمجموعات...) من التوكن مباشرة."""
    me = _tg_api(token, "getMe")
    photo_url = None
    try:
        photos = _tg_api(token, "getUserProfilePhotos", user_id=me["id"], limit=1)
        if photos and photos.get("total_count"):
            file_id = photos["photos"][0][-1]["file_id"]
            file_info = _tg_api(token, "getFile", file_id=file_id)
            photo_url = f"https://api.telegram.org/file/bot{token}/{file_info['file_path']}"
    except Exception:
        pass
    return {
        "id": me.get("id"),
        "username": me.get("username"),
        "first_name": me.get("first_name"),
        "can_join_groups": me.get("can_join_groups"),
        "can_read_all_group_messages": me.get("can_read_all_group_messages"),
        "photo_url": photo_url,
    }


def set_bot_name(token: str, name: str) -> None:
    _tg_api(token, "setMyName", name=name[:64])


def set_bot_photo_from_url(token: str, image_url: str) -> None:
    """يغيّر صورة البوت نفسه (setMyProfilePhoto) انطلاقاً من رابط صورة JPG يوفره المستخدم."""
    if not safe_url(image_url):
        raise ValueError("رابط الصورة غير مسموح")
    img = requests.get(image_url, timeout=15)
    img.raise_for_status()
    r = requests.post(
        f"https://api.telegram.org/bot{token}/setMyProfilePhoto",
        files={"bot_profile_jpg": ("photo.jpg", img.content, "image/jpeg")},
        data={"photo": json.dumps({"type": "static", "photo": "attach://bot_profile_jpg"})},
        timeout=20,
    )
    data = r.json()
    if not data.get("ok"):
        raise ValueError(data.get("description", "تعذر تغيير الصورة"))


# ---------------------------------------------------------------------------
# لوحة الويب (Flask)
# ---------------------------------------------------------------------------
app = Flask(__name__)
_config = load_config()
_config_lock = threading.RLock()


def _authorized() -> bool:
    if not PANEL_TOKEN:
        return True
    return secrets.compare_digest(request.headers.get("X-Panel-Token", ""), PANEL_TOKEN)


@app.get("/")
def index():
    return render_template(
        "panel.html",
        cfg=_config,
        blocks=BLOCKS,
        commands=BUILTIN_COMMANDS,
        categories=CATEGORIES,
        panel_protected=bool(PANEL_TOKEN),
    )


@app.get("/api/health")
def api_health():
    return jsonify(ok=True, running=bot_running(), blocks=len(BLOCKS), commands=len(BUILTIN_COMMANDS), users=user_count())


@app.get("/api/catalog")
def api_catalog():
    return jsonify(blocks=BLOCKS, commands=BUILTIN_COMMANDS, categories=CATEGORIES)


@app.post("/api/config")
@app.post("/api/start")
def api_save():
    global _config
    if not _authorized():
        return jsonify(message="غير مصرح"), 401
    data = request.get_json(silent=True) or {}
    with _config_lock:
        _config = {**_config, **data}
        _config["blocks"] = _config.get("blocks", [])[:MAX_BLOCKS]
        save_config(_config)
        current = dict(_config)
    if request.path.endswith("/start"):
        try:
            restart_bot(current)
        except Exception as e:
            return jsonify(message=f"تعذر تشغيل البوت: {e}"), 400
        return jsonify(status="success", message="تم حفظ الإعدادات وتشغيل البوت 🚀")
    return jsonify(status="success", message="تم حفظ الإعدادات")


@app.post("/api/stop")
def api_stop():
    if not _authorized():
        return jsonify(message="غير مصرح"), 401
    stop_bot()
    return jsonify(status="success", message="تم إيقاف البوت")


@app.post("/api/broadcast")
def api_broadcast():
    if not _authorized():
        return jsonify(message="غير مصرح"), 401
    if not _bot_instance:
        return jsonify(message="البوت غير شغال"), 400
    text = (request.get_json(silent=True) or {}).get("message", "").strip()
    if not text:
        return jsonify(message="اكتب رسالة أولاً"), 400
    sent = 0
    for uid in all_user_ids():
        try:
            _bot_instance.send_message(uid, text)
            sent += 1
        except Exception:
            pass
    return jsonify(status="success", message=f"تم الإرسال إلى {sent} مستخدم")


@app.get("/dashboard")
def dashboard():
    return render_template("dashboard.html", panel_protected=bool(PANEL_TOKEN))


@app.get("/api/bot-identity")
def api_bot_identity():
    if not _authorized():
        return jsonify(message="غير مصرح"), 401
    token = _config.get("token")
    if not token:
        return jsonify(message="لم يتم ضبط توكن البوت بعد"), 400
    try:
        return jsonify(status="success", **get_bot_identity(token))
    except Exception as e:
        return jsonify(message=f"تعذر جلب بيانات البوت: {e}"), 400


@app.post("/api/bot-identity/name")
def api_set_bot_name():
    if not _authorized():
        return jsonify(message="غير مصرح"), 401
    token = _config.get("token")
    name = (request.get_json(silent=True) or {}).get("name", "").strip()
    if not token:
        return jsonify(message="لم يتم ضبط توكن البوت بعد"), 400
    if not name:
        return jsonify(message="اكتب اسماً أولاً"), 400
    try:
        set_bot_name(token, name)
        return jsonify(status="success", message="تم تغيير اسم البوت")
    except Exception as e:
        return jsonify(message=f"تعذر تغيير الاسم: {e}"), 400


@app.post("/api/bot-identity/photo")
def api_set_bot_photo():
    if not _authorized():
        return jsonify(message="غير مصرح"), 401
    token = _config.get("token")
    image_url = (request.get_json(silent=True) or {}).get("image_url", "").strip()
    if not token:
        return jsonify(message="لم يتم ضبط توكن البوت بعد"), 400
    if not image_url:
        return jsonify(message="ضع رابط صورة أولاً"), 400
    try:
        set_bot_photo_from_url(token, image_url)
        return jsonify(status="success", message="تم تغيير صورة البوت")
    except Exception as e:
        return jsonify(message=f"تعذر تغيير الصورة: {e}"), 400


@app.get("/api/chats")
def api_chats():
    if not _authorized():
        return jsonify(message="غير مصرح"), 401
    return jsonify(status="success", chats=list_chats())


@app.get("/api/messages/<chat_id>")
def api_messages(chat_id):
    if not _authorized():
        return jsonify(message="غير مصرح"), 401
    limit = min(int(request.args.get("limit", 100)), 500)
    return jsonify(status="success", messages=list_messages(chat_id, limit))


application = app  # اسم بديل يقبله بعض منصات WSGI

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), threaded=True)
